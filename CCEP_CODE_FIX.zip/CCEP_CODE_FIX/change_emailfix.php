<?php
session_start();

if (!isset($_SESSION["logged_in"])) {
    header("Location: login.html");
    exit;
}
/* Checking that both CSRF tokens first exists and printing out error if not */
if (!isset($_POST["csrf_token"]) ||
    !isset($_SESSION["csrf_token"])) {

    http_response_code(403);
    exit("CSRF token missing - request rejected");
}

/* Checking that the submitted token matches the session token and exiting out with an error */
if (!hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])) {

    http_response_code(403);
    exit("Invalid CSRF token - request rejected");
}
/*If everything is satisfied and we dont exit out successfully echo the email*/
$email = $_POST["email"];
echo "New Email: $email<br>";
?>

